-- ---------------------
-- For require
-- ---------------------
package.path = "plugins/lib/?.lua;"..package.path


-- ---------------------
-- For Compatibility
-- ---------------------
file = File
